﻿namespace RusRuleti
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox oyuncu;
        private System.Windows.Forms.PictureBox hoppik;
        private System.Windows.Forms.PictureBox tufek;
        private System.Windows.Forms.ProgressBar oyuncuCanBar;
        private System.Windows.Forms.ProgressBar hoppikCanBar;
        private System.Windows.Forms.PictureBox arkaplan;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            int ekranGenislik = Screen.PrimaryScreen.Bounds.Width;
            int ekranYukseklik = Screen.PrimaryScreen.Bounds.Height;

            this.arkaplan = new System.Windows.Forms.PictureBox();
            this.oyuncu = new System.Windows.Forms.PictureBox();
            this.hoppik = new System.Windows.Forms.PictureBox();
            this.tufek = new System.Windows.Forms.PictureBox();
            this.oyuncuCanBar = new System.Windows.Forms.ProgressBar();
            this.hoppikCanBar = new System.Windows.Forms.ProgressBar();

            // Form Özellikleri
            this.ClientSize = new System.Drawing.Size(ekranGenislik, ekranYukseklik);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Controls.Add(this.arkaplan);
            this.Controls.Add(this.oyuncu);
            this.Controls.Add(this.hoppik);
            this.Controls.Add(this.tufek);
            this.Controls.Add(this.oyuncuCanBar);
            this.Controls.Add(this.hoppikCanBar);
            this.Text = "hoppik sokakları";

            // Arka Plan
            this.arkaplan.Image = System.Drawing.Image.FromFile("background.png");
            this.arkaplan.Size = new System.Drawing.Size(ekranGenislik, ekranYukseklik);
            this.arkaplan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.arkaplan.Location = new System.Drawing.Point(0, 0);
            this.arkaplan.SendToBack();

            // Oyuncu Resmi (Sol Taraf)
            this.oyuncu.Image = System.Drawing.Image.FromFile("sen.png");
            this.oyuncu.Size = new System.Drawing.Size(300, 300);
            this.oyuncu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.oyuncu.Location = new System.Drawing.Point(ekranGenislik / 10, ekranYukseklik / 2 + 50);
            this.oyuncu.BackColor = System.Drawing.ColorTranslator.FromHtml("#9BADB7");

            // Hoppik Resmi (Sağ Taraf - Biraz Sola Alındı)
            this.hoppik.Image = System.Drawing.Image.FromFile("hoppik.png");
            this.hoppik.Size = new System.Drawing.Size(300, 300);
            this.hoppik.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hoppik.Location = new System.Drawing.Point(ekranGenislik * 6 / 10, ekranYukseklik / 2 + 50);
            this.hoppik.BackColor = System.Drawing.ColorTranslator.FromHtml("#9BADB7");

            // Tüfek Resmi (Ortada)
            this.tufek.Image = System.Drawing.Image.FromFile("tufek.png");
            this.tufek.Size = new System.Drawing.Size(200, 200);
            this.tufek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tufek.Location = new System.Drawing.Point(ekranGenislik / 2 - 100, ekranYukseklik / 2 + 50);
            this.tufek.Click += new System.EventHandler(this.tufek_Click);

            // Oyuncu Can Barı (Hemen Altına Yakın)
            this.oyuncuCanBar.Maximum = 3;
            this.oyuncuCanBar.Value = 3;
            this.oyuncuCanBar.Size = new System.Drawing.Size(300, 20);
            this.oyuncuCanBar.Location = new System.Drawing.Point(ekranGenislik / 10, ekranYukseklik / 2 + 350);

            // Hoppik Can Barı (Hemen Altına Yakın)
            this.hoppikCanBar.Maximum = 3;
            this.hoppikCanBar.Value = 3;
            this.hoppikCanBar.Size = new System.Drawing.Size(300, 20);
            this.hoppikCanBar.Location = new System.Drawing.Point(ekranGenislik * 6 / 10, ekranYukseklik / 2 + 350);
        }
    }
}
